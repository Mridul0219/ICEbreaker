<?php
/* Kept for compatibility. The frontend now uses auth.php?action=login,
   but this endpoint works the same way and also starts the PHP session. */

require_once "helpers.php";
require_method("POST");

$email = strtolower(post_string("email", 150));
$password = (string)($_POST["password"] ?? "");

$alumni = login_user($conn, "alumni", $email, $password);

if (!$alumni) {
    throw new ApiException("Invalid email or password", 401);
}

json_response(["success" => true, "alumni" => $alumni]);
