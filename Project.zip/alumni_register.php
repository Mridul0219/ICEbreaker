<?php

require_once "helpers.php";
require_method("POST");

$name = post_string("name", 100);
$email = strtolower(post_string("email", 150));
$password = (string)($_POST["password"] ?? "");

if ($name === "" || $email === "" || $password === "") {
    throw new ApiException("Please fill in all required fields.", 400);
}
if (!valid_email($email)) {
    throw new ApiException("Please enter a valid email address.", 400);
}
if (strlen($password) < 6 || strlen($password) > 72) {
    throw new ApiException("Password must be between 6 and 72 characters.", 400);
}

$check = $conn->prepare("SELECT alumni_id FROM alumni WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$exists = $check->get_result()->num_rows > 0;
$check->close();

if ($exists) {
    throw new ApiException("Email already exists", 409);
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

try {
    $stmt = $conn->prepare(
        "INSERT INTO alumni (name, email, password) VALUES (?, ?, ?)"
    );
    $stmt->bind_param("sss", $name, $email, $hashedPassword);
    $stmt->execute();
    $stmt->close();
} catch (mysqli_sql_exception $e) {
    if ((int)$e->getCode() === 1062) {
        throw new ApiException("Email already exists", 409);
    }
    throw $e;
}

json_response(["success" => true, "message" => "Account created successfully"]);
