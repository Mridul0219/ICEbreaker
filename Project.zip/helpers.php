<?php
/*
 * Shared helpers for every AlumniBridge API endpoint.
 *  - DB connection ($conn)
 *  - PHP session (server-side authentication)
 *  - JSON responses + central error handling
 *  - input validation
 *  - notification creation
 */

require_once __DIR__ . "/db.php";

// Never print PHP warnings/errors into JSON responses; log them instead.
ini_set("display_errors", "0");
ini_set("log_errors", "1");
error_reporting(E_ALL);

/* ---------------------------------------------------------
   Response headers (all endpoints return JSON)
   --------------------------------------------------------- */
header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("X-Content-Type-Options: nosniff");

/* ---------------------------------------------------------
   Errors
   --------------------------------------------------------- */
class ApiException extends Exception
{
}

set_exception_handler(function (Throwable $e) {
    if ($e instanceof ApiException) {
        $status = $e->getCode() ?: 400;
        $message = $e->getMessage();
    } else {
        error_log("AlumniBridge error: " . $e->getMessage()
            . " in " . $e->getFile() . ":" . $e->getLine());
        $status = 500;
        $message = "An internal server error occurred.";
    }

    if (!headers_sent()) {
        http_response_code($status);
    }

    echo json_encode(["success" => false, "message" => $message]);
    exit;
});

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function require_method(string $method): void
{
    if (($_SERVER["REQUEST_METHOD"] ?? "") !== $method) {
        throw new ApiException("Invalid request method.", 405);
    }
}

/* ---------------------------------------------------------
   Session (server-side authentication)
   $_SESSION["role"]    = "student" | "alumni"
   $_SESSION["user_id"] = students.student_id | alumni.alumni_id
   --------------------------------------------------------- */
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off";

    ini_set("session.gc_maxlifetime", "7200");
    ini_set("session.use_strict_mode", "1");

    session_set_cookie_params([
        "lifetime" => 0,          // cookie lasts until the browser is closed
        "path"     => "/",
        "secure"   => $isHttps,
        "httponly" => true,       // JavaScript cannot read the session cookie
        "samesite" => "Lax"       // blocks cross-site POSTs (basic CSRF protection)
    ]);

    session_start();
}

function current_auth(): ?array
{
    $role = $_SESSION["role"] ?? "";
    $id = (int)($_SESSION["user_id"] ?? 0);

    if ($id > 0 && ($role === "student" || $role === "alumni")) {
        return ["role" => $role, "id" => $id];
    }
    return null;
}

/**
 * Returns ["role" => ..., "id" => ...] for the logged-in user or stops with
 * 401 (not logged in) / 403 (wrong role).
 */
function require_auth(?string $role = null): array
{
    $auth = current_auth();

    if (!$auth) {
        throw new ApiException("Your session has expired. Please log in again.", 401);
    }
    if ($role !== null && $auth["role"] !== $role) {
        throw new ApiException("You are not allowed to perform this action.", 403);
    }
    return $auth;
}

/* ---------------------------------------------------------
   Users / profiles (password is NEVER selected here)
   --------------------------------------------------------- */
function fetch_profile(mysqli $conn, string $role, int $id): ?array
{
    if ($role === "student") {
        $sql = "SELECT student_id, name, email, department, skills,
                       cv_link, portfolio_link
                FROM students WHERE student_id = ?";
    } else {
        $sql = "SELECT alumni_id, name, email, department, job_title, company,
                       skills, bio, linkedin_link, portfolio_link
                FROM alumni WHERE alumni_id = ?";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $row ?: null;
}

/** Profile + explicit role, so the frontend never confuses student 2 with alumni 2. */
function user_payload(array $profile, string $role): array
{
    $idKey = $role === "student" ? "student_id" : "alumni_id";
    return ["role" => $role, "id" => (int)$profile[$idKey]] + $profile;
}

function display_name(mysqli $conn, string $role, int $id): string
{
    $sql = $role === "student"
        ? "SELECT name FROM students WHERE student_id = ?"
        : "SELECT name FROM alumni WHERE alumni_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $row["name"] ?? ($role === "student" ? "A student" : "An alumni");
}

/**
 * Verifies email + password for the given role. On success starts a fresh
 * session and returns the safe profile; otherwise returns null.
 */
function login_user(mysqli $conn, string $role, string $email, string $password): ?array
{
    if ($role !== "student" && $role !== "alumni") {
        throw new ApiException("Invalid account type.", 400);
    }

    $sql = $role === "student"
        ? "SELECT student_id AS id, password FROM students WHERE email = ?"
        : "SELECT alumni_id AS id, password FROM alumni WHERE email = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || !password_verify($password, $row["password"])) {
        return null;
    }

    session_regenerate_id(true);           // prevents session fixation
    $_SESSION["role"] = $role;
    $_SESSION["user_id"] = (int)$row["id"];

    return fetch_profile($conn, $role, (int)$row["id"]);
}

/* ---------------------------------------------------------
   Input helpers
   --------------------------------------------------------- */
function post_string(string $key, int $maxLength = 255): string
{
    $value = trim((string)($_POST[$key] ?? ""));

    if (mb_strlen($value) > $maxLength) {
        $label = str_replace("_", " ", $key);
        throw new ApiException("The $label is too long (maximum $maxLength characters).", 400);
    }
    return $value;
}

function post_int(string $key): int
{
    $value = filter_var($_POST[$key] ?? null, FILTER_VALIDATE_INT);
    return ($value !== false && $value > 0) ? (int)$value : 0;
}

function get_int(string $key): int
{
    $value = filter_var($_GET[$key] ?? null, FILTER_VALIDATE_INT);
    return ($value !== false && $value > 0) ? (int)$value : 0;
}

function valid_email(string $email): bool
{
    return mb_strlen($email) <= 150 && filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/** Empty string => null (optional). Otherwise must be a valid http(s) URL. */
function optional_url(string $value, string $label): ?string
{
    if ($value === "") {
        return null;
    }
    $scheme = strtolower((string)parse_url($value, PHP_URL_SCHEME));

    if (
        mb_strlen($value) > 500 ||
        filter_var($value, FILTER_VALIDATE_URL) === false ||
        ($scheme !== "http" && $scheme !== "https")
    ) {
        throw new ApiException("$label must be a valid link starting with http:// or https://", 400);
    }
    return $value;
}

function empty_to_null(string $value): ?string
{
    return $value === "" ? null : $value;
}

function valid_date(string $date): bool
{
    $d = DateTime::createFromFormat("Y-m-d", $date);
    return $d && $d->format("Y-m-d") === $date;
}

/** Accepts HH:MM or HH:MM:SS, returns HH:MM:SS or null. */
function normalize_time(string $time): ?string
{
    if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/', $time, $m)) {
        return null;
    }
    return $m[1] . ":" . $m[2] . ":" . ($m[3] ?? "00");
}

function slot_text(string $date, string $startTime): string
{
    return date("M j, Y", strtotime($date)) . " at " . date("g:i A", strtotime($startTime));
}

/* ---------------------------------------------------------
   Transactions
   --------------------------------------------------------- */
function with_transaction(mysqli $conn, callable $callback)
{
    $conn->begin_transaction();
    try {
        $result = $callback();
        $conn->commit();
        return $result;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/* ---------------------------------------------------------
   Notifications (created server-side, inside the same transaction
   as the action that caused them)
   --------------------------------------------------------- */
function add_notification(
    mysqli $conn,
    string $recipientRole,
    int $recipientId,
    string $title,
    string $message
): void {
    if ($recipientRole === "student") {
        $stmt = $conn->prepare(
            "INSERT INTO notifications (student_id, alumni_id, title, message)
             VALUES (?, NULL, ?, ?)"
        );
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO notifications (student_id, alumni_id, title, message)
             VALUES (NULL, ?, ?, ?)"
        );
    }

    $stmt->bind_param("iss", $recipientId, $title, $message);
    $stmt->execute();
    $stmt->close();
}
