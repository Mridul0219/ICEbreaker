/* =========================================================
   ALUMNI BRIDGE - COMPLETE JAVASCRIPT
   Compatible with the updated index.html + styles.css

   Data flow:  UI -> fetch() -> PHP API -> MySQL -> JSON -> UI
   The logged-in user is tracked by a PHP session (cookie).
   JavaScript keeps the current user only IN MEMORY (asked from
   auth.php on page load) - nothing is persisted in localStorage.
   ========================================================= */

let selectedAuthRole = "student";

// In-memory copy of the logged-in user: { role, id, name, email, ... }.
// "id" is student_id for students and alumni_id for alumni - always use it together with "role".
let currentUser = null;

let mentorCache = null;            // last alumni list (used by the search box)
let alumniReferralCache = [];      // last referral list shown to the alumni
let unreadNotificationCount = 0;
let notificationTimer = null;

/* =========================================================
   API HELPER
   ========================================================= */
/**
 * Calls a PHP endpoint and returns the parsed JSON.
 * Throws an Error (with a user-friendly message) for network problems,
 * invalid JSON, HTTP errors and { success: false } responses.
 */
async function apiRequest(url, { method = "GET", data = null, skipAuthRedirect = false } = {}) {
    const options = { method, credentials: "same-origin", cache: "no-store" };

    if (data) {
        const formData = new FormData();
        Object.entries(data).forEach(([key, value]) => formData.append(key, value ?? ""));
        options.body = formData;
    }

    let response;
    try {
        response = await fetch(url, options);
    } catch (error) {
        console.error("Network error:", url, error);
        throw new Error("Cannot reach the server. Please check that Apache and MySQL are running.");
    }

    const text = await response.text();
    let result;
    try {
        result = JSON.parse(text);
    } catch (error) {
        console.error("Invalid JSON from", url, "->", text);
        throw new Error("The server returned an unexpected response.");
    }

    if (response.status === 401 && !skipAuthRedirect) {
        handleSessionExpired();
        const expired = new Error(result.message || "Your session has expired. Please log in again.");
        expired.handled = true;
        throw expired;
    }

    if (!response.ok || result.success === false) {
        throw new Error(result.message || `Request failed (${response.status}).`);
    }

    return result;
}

function handleApiError(error) {
    if (error && error.handled) return;   // already shown (session expired)
    console.error(error);
    showToast(error?.message || "Something went wrong.");
}

function handleSessionExpired() {
    if (!currentUser) return;
    showAuthScreen();
    showToast("Your session has expired. Please log in again.");
}

function getCurrentUser() {
    return currentUser;
}

/* =========================================================
   UTILITY HELPERS
   ========================================================= */
function capitalize(text) {
    if (!text) return "";
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function getInitials(name) {
    if (!name) return "U";
    return name.trim().split(/\s+/).slice(0, 2).map(word => word.charAt(0).toUpperCase()).join("");
}

function escapeHTML(value) {
    if (value === undefined || value === null) return "";
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Only http(s) links may be rendered as clickable links (blocks javascript: URLs).
function safeUrl(url) {
    try {
        const parsed = new URL(url);
        return (parsed.protocol === "http:" || parsed.protocol === "https:") ? escapeHTML(url) : "";
    } catch (error) {
        return "";
    }
}

function getTodayDate() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function formatDate(dateString) {
    if (!dateString) return "";
    const date = new Date(dateString + "T00:00:00");
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function formatTime(time) {
    if (!time) return "";
    const parts = time.split(":");
    let hour = parseInt(parts[0]);
    const minute = parts[1] || "00";
    const suffix = hour >= 12 ? "PM" : "AM";
    hour = hour % 12 || 12;
    return `${hour}:${minute} ${suffix}`;
}

function formatDateTime(date, time) {
    return `${formatDate(date)} at ${formatTime(time)}`;
}

function minutesBetween(start, end) {
    const toMinutes = t => {
        const [h, m] = t.split(":").map(Number);
        return h * 60 + m;
    };
    return toMinutes(end) - toMinutes(start);
}

function formatNotificationTime(dateString) {
    // MySQL returns "YYYY-MM-DD HH:MM:SS"; the "T" makes it parse in every browser.
    const date = new Date(String(dateString).replace(" ", "T"));
    if (isNaN(date)) return "";
    return date.toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

function showToast(message) {
    const toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 3000);
}

/* =========================================================
   AUTH LOGIC
   ========================================================= */
function hideAuthBoxes() {
    ["roleSelection", "loginBox", "signupBox", "forgotBox"].forEach(id => {
        document.getElementById(id)?.classList.add("hidden");
    });
}

function showRoleSelection() {
    hideAuthBoxes();
    document.getElementById("roleSelection")?.classList.remove("hidden");
}

function selectAuthRole(role) {
    selectedAuthRole = role;
    hideAuthBoxes();
    document.getElementById("loginBox")?.classList.remove("hidden");
    const roleText = document.getElementById("loginRoleText");
    if (roleText) {
        roleText.textContent = `Login as ${capitalize(role)}`;
    }
}

function showLogin() {
    hideAuthBoxes();
    document.getElementById("loginBox")?.classList.remove("hidden");
}

function showSignup() {
    hideAuthBoxes();
    document.getElementById("signupBox")?.classList.remove("hidden");
    const roleText = document.getElementById("signupRoleText");
    if (roleText) {
        roleText.textContent = `Create a ${capitalize(selectedAuthRole)} account`;
    }
    updateSignupFields();
}

function showForgotPassword() {
    hideAuthBoxes();
    document.getElementById("forgotBox")?.classList.remove("hidden");
}

function updateSignupFields() {
    const studentFields = document.getElementById("studentSignupFields");
    const alumniFields = document.getElementById("alumniSignupFields");
    if (!studentFields || !alumniFields) return;

    if (selectedAuthRole === "student") {
        studentFields.classList.remove("hidden");
        alumniFields.classList.add("hidden");
    } else {
        studentFields.classList.add("hidden");
        alumniFields.classList.remove("hidden");
    }
}

async function signup(event) {
    event.preventDefault();

    const name = document.getElementById("signupName")?.value.trim();
    const email = document.getElementById("signupEmail")?.value.trim().toLowerCase();
    const password = document.getElementById("signupPassword")?.value;
    const confirmPassword = document.getElementById("signupConfirmPassword")?.value;

    if (!name || !email || !password) {
        showToast("Please fill in all required fields.");
        return;
    }

    if (password !== confirmPassword) {
        showToast("Passwords do not match.");
        return;
    }

    const endpoint = selectedAuthRole === "alumni" ? "alumni_register.php" : "student_register.php";

    try {
        await apiRequest(endpoint, { method: "POST", data: { name, email, password } });

        showToast("Account created successfully.");
        document.getElementById("signupForm")?.reset();
        showLogin();
    } catch (error) {
        handleApiError(error);
    }
}

async function login(event) {
    event.preventDefault();

    const email = document.getElementById("loginEmail")?.value.trim().toLowerCase();
    const password = document.getElementById("loginPassword")?.value;

    if (!email || !password) {
        showToast("Please enter email and password.");
        return;
    }

    try {
        // The server checks the password (password_verify) and starts the PHP session.
        const result = await apiRequest("auth.php", {
            method: "POST",
            data: { action: "login", role: selectedAuthRole, email, password },
            skipAuthRedirect: true
        });

        document.getElementById("loginForm")?.reset();
        enterApp(result.user);
    } catch (error) {
        handleApiError(error);
    }
}

// Shows the correct app for a user the server has authenticated.
function enterApp(user) {
    currentUser = user;
    selectedAuthRole = user.role;
    mentorCache = null;

    document.getElementById("authPage")?.classList.add("hidden");
    document.getElementById("studentApp")?.classList.toggle("hidden", user.role !== "student");
    document.getElementById("alumniApp")?.classList.toggle("hidden", user.role !== "alumni");

    applyUserToHeader();

    if (user.role === "student") {
        showStudentPage("dashboard");
    } else {
        showAlumniPage("dashboard");
    }

    startNotificationPolling();
}

function applyUserToHeader() {
    if (!currentUser) return;
    const prefix = currentUser.role;   // "student" or "alumni"
    const headerName = document.getElementById(`${prefix}HeaderName`);
    const welcomeName = document.getElementById(`${prefix}WelcomeName`);
    if (headerName) headerName.textContent = currentUser.name;
    if (welcomeName) welcomeName.textContent = currentUser.name;
}

// Removes everything belonging to the previous user from the page.
function clearUiState() {
    currentUser = null;
    mentorCache = null;
    alumniReferralCache = [];
    unreadNotificationCount = 0;

    clearInterval(notificationTimer);
    notificationTimer = null;

    [
        "studentRecommendedMentors", "studentMentorList", "studentSessionList", "studentReferralList",
        "alumniRecentRequests", "alumniRequestList", "alumniAvailabilityList", "alumniReferralList",
        "studentNotificationList", "alumniNotificationList"
    ].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.innerHTML = "";
    });

    [
        "studentMentorCount", "studentSessionCount", "studentReferralCount",
        "alumniSlotCount", "alumniPendingCount", "alumniReferralCount"
    ].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.textContent = "0";
    });

    [
        "studentProfileName", "studentProfileEmail", "studentProfileDepartment", "studentProfileSkills",
        "studentProfileCvLink", "studentProfilePortfolioLink",
        "alumniProfileName", "alumniProfileEmail", "alumniProfileCompany", "alumniProfileJob",
        "alumniProfileSkills", "alumniProfileBio", "mentorSearch"
    ].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = "";
    });

    ["studentNotificationBadge", "alumniNotificationBadge"].forEach(id => {
        document.getElementById(id)?.classList.add("hidden");
    });
    ["studentNotificationPanel", "alumniNotificationPanel"].forEach(id => {
        document.getElementById(id)?.classList.remove("show");
    });

    closeModal();
}

function showAuthScreen() {
    clearUiState();
    document.getElementById("studentApp")?.classList.add("hidden");
    document.getElementById("alumniApp")?.classList.add("hidden");
    document.getElementById("authPage")?.classList.remove("hidden");
    showRoleSelection();
}

async function logout() {
    try {
        await apiRequest("auth.php", { method: "POST", data: { action: "logout" }, skipAuthRedirect: true });
    } catch (error) {
        console.error(error);   // even if this fails, leave the UI logged-out
    }

    showAuthScreen();
    showToast("Logged out successfully.");
}

async function resetPassword(event) {
    event.preventDefault();
    const email = document.getElementById("forgotEmail")?.value.trim().toLowerCase();

    try {
        const result = await apiRequest("auth.php", {
            method: "POST",
            data: { action: "forgot_password", email },
            skipAuthRedirect: true
        });
        showToast(result.message);
        document.getElementById("forgotForm")?.reset();
        showLogin();
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   NAVIGATION
   ========================================================= */
function showStudentPage(page) {
    if (currentUser?.role !== "student") return;

    ["dashboard", "mentors", "sessions", "referrals", "profile"].forEach(name => {
        document.getElementById(`student${capitalize(name)}Page`)?.classList.add("hidden");
    });
    document.getElementById(`student${capitalize(page)}Page`)?.classList.remove("hidden");

    if (page === "dashboard") loadStudentDashboard();
    if (page === "mentors") loadStudentMentors(true);
    if (page === "sessions") loadStudentSessions();
    if (page === "referrals") loadStudentReferrals();
    if (page === "profile") loadStudentProfile();

    updateAllNotifications();
}

function showAlumniPage(page) {
    if (currentUser?.role !== "alumni") return;

    ["dashboard", "requests", "availability", "referrals", "profile"].forEach(name => {
        document.getElementById(`alumni${capitalize(name)}Page`)?.classList.add("hidden");
    });
    document.getElementById(`alumni${capitalize(page)}Page`)?.classList.remove("hidden");

    if (page === "dashboard") loadAlumniDashboard();
    if (page === "requests") loadAlumniRequests();
    if (page === "availability") loadAlumniAvailability();
    if (page === "referrals") loadAlumniReferrals();
    if (page === "profile") loadAlumniProfile();

    updateAllNotifications();
}

/* =========================================================
   STUDENT DASHBOARD
   ========================================================= */
async function loadStudentDashboard() {
    const user = getCurrentUser();
    if (!user || user.role !== "student") return;

    applyUserToHeader();

    try {
        const [mentorsResult, sessionsResult, referralsResult] = await Promise.all([
            apiRequest("get_alumni.php"),
            apiRequest("get_sessions.php"),
            apiRequest("get_referrals.php")
        ]);

        const mentorCount = document.getElementById("studentMentorCount");
        const sessionCount = document.getElementById("studentSessionCount");
        const referralCount = document.getElementById("studentReferralCount");

        if (mentorCount) mentorCount.textContent = mentorsResult.alumni.length;
        if (sessionCount) sessionCount.textContent = sessionsResult.sessions.length;
        if (referralCount) referralCount.textContent = referralsResult.referrals.length;

        mentorCache = mentorsResult.alumni;
        loadRecommendedMentors(mentorsResult.alumni);
    } catch (error) {
        handleApiError(error);
    }
}

function loadRecommendedMentors(allMentors) {
    const container = document.getElementById("studentRecommendedMentors");
    if (!container) return;

    const mentors = (allMentors || []).slice(0, 6);

    if (mentors.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">👨‍💼</div>
                No alumni mentors available yet.
            </div>
        `;
        return;
    }
    container.innerHTML = mentors.map(mentor => createMentorCard(mentor)).join("");
}

/* =========================================================
   STUDENT MENTORS
   ========================================================= */
// refresh=true re-reads alumni from MySQL; the search box calls this without
// arguments and simply filters the list that was loaded when the page opened.
async function loadStudentMentors(refresh = false) {
    const container = document.getElementById("studentMentorList");
    if (!container) return;

    const search = document.getElementById("mentorSearch")?.value.trim().toLowerCase() || "";

    try {
        if (refresh || !mentorCache) {
            const result = await apiRequest("get_alumni.php");
            mentorCache = result.alumni;
        }

        const mentors = mentorCache.filter(mentor => {
            const text = [mentor.name, mentor.company, mentor.job_title, mentor.skills, mentor.bio]
                .join(" ")
                .toLowerCase();
            return text.includes(search);
        });

        if (mentors.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    No mentors found.
                </div>
            `;
            return;
        }

        container.innerHTML = mentors.map(mentor => createMentorCard(mentor)).join("");
    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `
            <div class="empty-state">
                ${escapeHTML(error.message || "Failed to load alumni.")}
            </div>
        `;
    }
}

function createMentorCard(mentor) {
    return `
        <div class="mentor-card">

            <div class="mentor-top">

                <div class="mentor-avatar">
                    ${escapeHTML(getInitials(mentor.name))}
                </div>

                <div>

                    <h3>
                        ${escapeHTML(mentor.name)}
                    </h3>

                    <div class="job-title">
                        ${escapeHTML(mentor.job_title || "Alumni")}
                    </div>

                </div>

            </div>

            <div class="mentor-company">
                🏢
                ${escapeHTML(mentor.company || "Company not specified")}
            </div>

            <p>
                ${escapeHTML(mentor.bio || "Experienced alumni available to guide students.")}
            </p>

            ${mentor.skills
                ? `
                        <p>
                            <strong>Skills:</strong>
                            ${escapeHTML(mentor.skills)}
                        </p>
                      `
                : ""}

            <div class="mentor-actions">

                <button
                    class="secondary-button"
                    onclick="openAlumniProfileModal(${Number(mentor.alumni_id)})">
                    View Full Profile
                </button>

                <button
                    class="secondary-button"
                    onclick="openMentorSessionModal(${Number(mentor.alumni_id)})">
                    Request Session
                </button>

                <button
                    class="primary-button"
                    onclick="openReferralRequestModal(${Number(mentor.alumni_id)})">
                    Request Referral
                </button>

            </div>

        </div>
    `;
}

/* =========================================================
   ALUMNI FULL PROFILE MODAL
   ========================================================= */
async function openAlumniProfileModal(alumniId) {
    try {
        const id = encodeURIComponent(alumniId);
        const [alumniResult, availabilityResult] = await Promise.all([
            apiRequest(`get_alumni.php?alumni_id=${id}`),
            apiRequest(`get_availability.php?alumni_id=${id}`)
        ]);

        const alumni = alumniResult.alumni[0];
        if (!alumni) {
            showToast("Alumni profile not found.");
            return;
        }

        const today = getTodayDate();
        const slots = availabilityResult.availability
            .filter(slot => slot.status === "available" && slot.available_date >= today)
            .sort((a, b) => (a.available_date + a.start_time).localeCompare(b.available_date + b.start_time));

        const availableSlots = slots.length
            ? slots.map(slot => `
            <div class="profile-slot">
                <span>📅 ${formatDateTime(slot.available_date, slot.start_time)}</span>
                <span>${minutesBetween(slot.start_time, slot.end_time)} mins</span>
            </div>
        `).join("")
            : `<p class="profile-muted">No available slots at the moment.</p>`;

        const html = `
        <div class="alumni-profile-modal">
            <div class="profile-modal-header">
                <div class="mentor-avatar profile-avatar">${escapeHTML(getInitials(alumni.name))}</div>
                <div>
                    <h2 class="modal-title">${escapeHTML(alumni.name)}</h2>
                    <p class="profile-job">${escapeHTML(alumni.job_title || "Alumni")}</p>
                </div>
            </div>
            <div class="profile-details">
                <div class="profile-detail-item"><strong>📧 Email</strong><span>${escapeHTML(alumni.email || "Not specified")}</span></div>
                <div class="profile-detail-item"><strong>🏢 Company</strong><span>${escapeHTML(alumni.company || "Not specified")}</span></div>
                <div class="profile-detail-item"><strong>🎓 Department</strong><span>${escapeHTML(alumni.department || "Not specified")}</span></div>
                <div class="profile-detail-item"><strong>🛠️ Skills</strong><span>${escapeHTML(alumni.skills || "Not specified")}</span></div>
            </div>
            <div class="profile-section">
                <h3>About</h3>
                <p>${escapeHTML(alumni.bio || "No bio provided.")}</p>
            </div>
            <div class="profile-section">
                <h3>Available Mentorship Slots</h3>
                ${availableSlots}
            </div>
            <div class="mentor-actions profile-actions">
                <button class="secondary-button" onclick="closeModal()">Close</button>
                <button class="primary-button" onclick="closeModal(); openMentorSessionModal(${Number(alumni.alumni_id)})">Request Session</button>
            </div>
        </div>
    `;
        openModal(html);
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   STUDENT SESSIONS
   ========================================================= */
async function loadStudentSessions() {
    const container = document.getElementById("studentSessionList");
    if (!container) return;

    try {
        const result = await apiRequest("get_sessions.php");
        const sessions = result.sessions;

        if (sessions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📅</div>
                    No mentorship sessions yet.
                </div>
            `;
            return;
        }

        container.innerHTML = sessions.map(session => {
            const dateTime = formatDateTime(session.session_date, session.start_time.substring(0, 5));

            return `
                    <div class="data-card">

                        <div>

                            <h3>
                                ${escapeHTML(session.alumni_name || "Alumni")}
                            </h3>

                            <p>
                                ${escapeHTML(session.alumni_company || "")}
                            </p>

                            <p>
                                📅 ${dateTime}
                            </p>

                            <span class="status status-${getSessionStatusClass(session.status)}">
                                ${capitalize(session.status)}
                            </span>

                        </div>

                        <div class="data-card-actions">

                            ${(session.status === "pending" || session.status === "confirmed")
                    ? `
                                    <button
                                        class="danger-button"
                                        onclick="cancelSession(${Number(session.session_id)})">
                                        Cancel Session
                                    </button>
                                  `
                    : ""}

                        </div>

                    </div>
                `;
        }).join("");
    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `
            <div class="empty-state">
                ${escapeHTML(error.message || "Failed to load mentorship sessions.")}
            </div>
        `;
    }
}

function getSessionStatusClass(status) {
    if (status === "confirmed") return "confirmed";
    if (status === "cancelled") return "cancelled";
    return "pending";
}

/* =========================================================
   MENTORSHIP SESSION REQUEST
   ========================================================= */
async function openMentorSessionModal(alumniId) {
    try {
        const result = await apiRequest(`get_availability.php?alumni_id=${encodeURIComponent(alumniId)}`);

        const today = getTodayDate();
        const slots = result.availability.filter(slot =>
            slot.status === "available" && slot.available_date >= today
        );

        if (slots.length === 0) {
            showToast("This alumni has no available session slots.");
            return;
        }

        const html = `
                <h2 class="modal-title">
                    Request Mentorship Session
                </h2>

                <p class="modal-subtitle">
                    Select a time slot and send a message to the alumni.
                </p>

                <form onsubmit="requestMentorshipSession(event, ${Number(alumniId)})">

                    <div class="form-group">
                        <label>Select Available Slot</label>

                        <select id="sessionSlot" required>

                            <option value="">
                                Select a slot
                            </option>

                            ${slots.map(slot => `
                                    <option value="${Number(slot.availability_id)}">
                                        ${formatDateTime(slot.available_date, slot.start_time.substring(0, 5))}
                                        -
                                        ${formatTime(slot.end_time.substring(0, 5))}
                                    </option>
                                `).join("")}

                        </select>
                    </div>

                    <div class="form-group">

                        <label>Message</label>

                        <textarea
                            id="sessionMessage"
                            placeholder="Tell the alumni what you want to discuss..."
                            required
                        ></textarea>

                    </div>

                    <button
                        type="submit"
                        class="primary-button">
                        Send Session Request
                    </button>

                </form>
            `;

        openModal(html);
    } catch (error) {
        handleApiError(error);
    }
}

async function requestMentorshipSession(event, alumniId) {
    event.preventDefault();

    const slotId = document.getElementById("sessionSlot")?.value;
    const message = document.getElementById("sessionMessage")?.value.trim();

    if (!slotId || !message) {
        showToast("Please select a slot and enter a message.");
        return;
    }

    try {
        // The student is identified by the PHP session - no student_id is sent.
        await apiRequest("sessions.php", {
            method: "POST",
            data: { action: "create", alumni_id: alumniId, availability_id: slotId, message }
        });

        closeModal();
        showToast("Mentorship request sent successfully.");
        loadStudentSessions();
        loadStudentDashboard();
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   CANCEL SESSION
   ========================================================= */
function openCancelSessionModal(sessionId) {
    const html = `
        <h2 class="modal-title">Cancel Session</h2>
        <p class="modal-subtitle">Please provide a reason for cancelling this session.</p>
        <form onsubmit="confirmCancelSession(event, ${Number(sessionId)})">
            <div class="form-group">
                <label>Reason for Cancellation</label>
                <textarea id="cancelReason" placeholder="Enter reason..." required></textarea>
            </div>
            <button type="submit" class="danger-button full-width">Confirm Cancellation</button>
        </form>
    `;
    openModal(html);
}

function confirmCancelSession(event, sessionId) {
    event.preventDefault();
    const reason = document.getElementById("cancelReason")?.value.trim();
    cancelSession(sessionId, reason);
    closeModal();
}

async function cancelSession(sessionId, reason = "") {
    const user = getCurrentUser();
    if (!user) {
        showToast("Please log in again.");
        return;
    }

    try {
        // The server decides whose session this is from the PHP session.
        await apiRequest("sessions.php", {
            method: "POST",
            data: { action: "cancel", session_id: sessionId, reason }
        });

        showToast("Session cancelled successfully.");

        if (user.role === "student") {
            loadStudentSessions();
            loadStudentDashboard();
        } else {
            loadAlumniRequests();
            loadAlumniDashboard();
        }

        updateAllNotifications();
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   ALUMNI DASHBOARD
   ========================================================= */
async function loadAlumniDashboard() {
    const alumni = getCurrentUser();
    if (!alumni || alumni.role !== "alumni") return;

    applyUserToHeader();

    try {
        const [availabilityResult, sessionsResult, referralsResult] = await Promise.all([
            apiRequest("get_availability.php"),
            apiRequest("get_sessions.php"),
            apiRequest("get_referrals.php")
        ]);

        const slots = availabilityResult.availability.filter(s => s.status === "available");
        const pendingSessions = sessionsResult.sessions.filter(s => s.status === "pending");
        const pendingReferrals = referralsResult.referrals.filter(r => r.status === "pending");

        const slotCount = document.getElementById("alumniSlotCount");
        const pendingCount = document.getElementById("alumniPendingCount");
        const referralCount = document.getElementById("alumniReferralCount");

        if (slotCount) slotCount.textContent = slots.length;
        if (pendingCount) pendingCount.textContent = pendingSessions.length;
        if (referralCount) referralCount.textContent = pendingReferrals.length;

        loadAlumniRecentRequests(pendingSessions);
    } catch (error) {
        handleApiError(error);
    }
}

function loadAlumniRecentRequests(pendingSessions) {
    const container = document.getElementById("alumniRecentRequests");
    if (!container) return;

    const sessions = (pendingSessions || []).slice(0, 5);

    if (sessions.length === 0) {
        container.innerHTML = `<div class="empty-state">No pending requests.</div>`;
        return;
    }

    container.innerHTML = sessions.map(session => `
            <div class="data-card">
                <div>
                    <h3>${escapeHTML(session.student_name || "Student")}</h3>
                    <p>Requested a mentorship session.</p>
                </div>
                <div class="data-card-actions">
                    <button class="primary-button" onclick="showAlumniPage('requests')">View Request</button>
                </div>
            </div>
        `).join("");
}

/* =========================================================
   ALUMNI REQUESTS
   ========================================================= */
async function loadAlumniRequests() {
    const container = document.getElementById("alumniRequestList");
    if (!container) return;

    try {
        const result = await apiRequest("get_sessions.php");
        const sessions = result.sessions;

        if (sessions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📩</div>
                    No mentorship requests.
                </div>
            `;
            return;
        }

        container.innerHTML = sessions.map(session => {
            const id = Number(session.session_id);

            return `
                    <div class="data-card">

                        <div>

                            <h3>
                                ${escapeHTML(session.student_name || "Student")}
                            </h3>

                            <p>
                                ${escapeHTML(session.student_department || "")}
                            </p>

                            <p>
                                📅
                                ${formatDateTime(session.session_date, session.start_time.substring(0, 5))}
                            </p>

                            <p>
                                ${escapeHTML(session.message || "")}
                            </p>

                            <span class="status status-${getSessionStatusClass(session.status)}">
                                ${capitalize(session.status)}
                            </span>

                        </div>

                        <div class="data-card-actions">

                            ${session.status === "pending"
                    ? `
                                    <button
                                        class="success-button"
                                        onclick="acceptSession(${id})">
                                        Accept
                                    </button>

                                    <button
                                        class="danger-button"
                                        onclick="declineSession(${id})">
                                        Decline
                                    </button>

                                    <button
                                        class="danger-button"
                                        onclick="openCancelSessionModal(${id})">
                                        Cancel Session
                                    </button>
                                  `
                    : session.status === "confirmed"
                        ? `
                                    <button
                                        class="danger-button"
                                        onclick="openCancelSessionModal(${id})">
                                        Cancel Session
                                    </button>
                                  `
                        : ""}

                        </div>

                    </div>
                `;
        }).join("");
    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `
            <div class="empty-state">
                ${escapeHTML(error.message || "Failed to load mentorship requests.")}
            </div>
        `;
    }
}

async function acceptSession(sessionId) {
    try {
        await apiRequest("sessions.php", {
            method: "POST",
            data: { action: "accept", session_id: sessionId }
        });

        showToast("Session accepted.");
        loadAlumniRequests();
        loadAlumniDashboard();
    } catch (error) {
        handleApiError(error);
        loadAlumniRequests();   // the list may be stale (e.g. slot was booked meanwhile)
    }
}

async function declineSession(sessionId) {
    try {
        await apiRequest("sessions.php", {
            method: "POST",
            data: { action: "decline", session_id: sessionId }
        });

        showToast("Session request declined.");
        loadAlumniRequests();
        loadAlumniDashboard();
    } catch (error) {
        handleApiError(error);
        loadAlumniRequests();
    }
}

/* =========================================================
   ALUMNI AVAILABILITY
   ========================================================= */
async function loadAlumniAvailability() {
    const container = document.getElementById("alumniAvailabilityList");
    if (!container) return;

    try {
        // For an alumni, the server always returns their OWN slots.
        const result = await apiRequest("get_availability.php");
        const slots = result.availability;

        if (slots.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📅</div>
                    No availability added yet.
                </div>
            `;
            return;
        }

        container.innerHTML = slots.map(slot => {
            const startTime = slot.start_time.substring(0, 5);
            const endTime = slot.end_time.substring(0, 5);

            return `
                    <div class="availability-card">

                        <h3>${formatDate(slot.available_date)}</h3>

                        <div class="availability-date">
                            ${formatTime(startTime)} - ${formatTime(endTime)}
                        </div>

                        <span class="status ${slot.status === "available" ? "status-confirmed" : "status-pending"}">
                            ${capitalize(slot.status)}
                        </span>

                        ${slot.status === "available"
                    ? `
                                    <br><br>
                                    <button
                                        class="danger-button"
                                        onclick="deleteAvailability(${Number(slot.availability_id)})">
                                        Remove Slot
                                    </button>
                                  `
                    : ""}

                    </div>
                `;
        }).join("");
    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `
            <div class="empty-state">
                ${escapeHTML(error.message || "Failed to load availability.")}
            </div>
        `;
    }
}

function openAvailabilityModal() {
    const html = `
        <h2 class="modal-title">Add Availability</h2>
        <p class="modal-subtitle">Students will be able to request sessions during this time.</p>
        <form onsubmit="addAvailability(event)">
            <div class="form-group">
                <label>Date</label>
                <input type="date" id="availDate" min="${getTodayDate()}" required>
            </div>
            <div class="form-group">
                <label>Start Time</label>
                <input type="time" id="availTime" required>
            </div>
            <div class="form-group">
                <label>Duration (Minutes)</label>
                <select id="availDuration">
                    <option value="30">30 minutes</option>
                    <option value="45">45 minutes</option>
                    <option value="60" selected>60 minutes</option>
                </select>
            </div>
            <button type="submit" class="primary-button full-width">Add Slot</button>
        </form>
    `;
    openModal(html);
}

async function addAvailability(event) {
    event.preventDefault();

    const date = document.getElementById("availDate")?.value;
    const time = document.getElementById("availTime")?.value;
    const duration = parseInt(document.getElementById("availDuration")?.value);

    if (!date || !time || !duration) {
        showToast("Please fill all availability fields.");
        return;
    }

    try {
        await apiRequest("availability.php", {
            method: "POST",
            data: { action: "add", date, start_time: time, duration }
        });

        closeModal();
        showToast("Availability slot added.");
        loadAlumniAvailability();
        loadAlumniDashboard();
    } catch (error) {
        handleApiError(error);
    }
}

async function deleteAvailability(slotId) {
    try {
        await apiRequest("availability.php", {
            method: "POST",
            data: { action: "delete", availability_id: slotId }
        });

        showToast("Slot removed.");
        loadAlumniAvailability();
        loadAlumniDashboard();
    } catch (error) {
        handleApiError(error);
        loadAlumniAvailability();
    }
}

/* =========================================================
   REFERRALS
   ========================================================= */
async function openReferralRequestModal(alumniId = "") {
    try {
        const result = await apiRequest("get_alumni.php");
        const mentors = result.alumni;

        if (mentors.length === 0) {
            showToast("No alumni available for referral requests.");
            return;
        }

        const defaultCv = currentUser?.cv_link || "";
        const defaultPortfolio = currentUser?.portfolio_link || "";

        const html = `
                <h2 class="modal-title">
                    Request Job Referral
                </h2>

                <p class="modal-subtitle">
                    Ask an alumni to refer you for an open position
                </p>

                <form onsubmit="submitReferralRequest(event)">

                    <div class="form-group">

                        <label>Select Alumni Mentor</label>

                        <select id="referralAlumni" required>

                            <option value="">
                                Choose mentor
                            </option>

                            ${mentors.map(person => `
                                <option
                                    value="${Number(person.alumni_id)}"
                                    ${String(person.alumni_id) === String(alumniId) ? "selected" : ""}
                                >
                                    ${escapeHTML(person.name)}
                                    -
                                    ${escapeHTML(person.company || "Company not specified")}
                                </option>
                            `).join("")}

                        </select>

                    </div>


                    <div class="form-group">

                        <label>Target Company</label>

                        <input
                            type="text"
                            id="referralCompany"
                            placeholder="e.g. Google, Microsoft"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>Job / Position</label>

                        <input
                            type="text"
                            id="referralPosition"
                            placeholder="e.g. Software Engineer"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            CV Link
                            <span style="font-weight:400; color:#6b7280;">
                                (Google Drive, Dropbox, etc.)
                            </span>
                        </label>

                        <input
                            type="url"
                            id="referralCvLink"
                            placeholder="https://drive.google.com/..."
                            value="${escapeHTML(defaultCv)}"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            Portfolio / GitHub / Previous Job Link
                            <span style="font-weight:400; color:#6b7280;">
                                (Optional)
                            </span>
                        </label>

                        <input
                            type="url"
                            id="referralPortfolioLink"
                            placeholder="https://github.com/..."
                            value="${escapeHTML(defaultPortfolio)}"
                        >

                    </div>


                    <div class="form-group">

                        <label>Message to Alumni</label>

                        <textarea
                            id="referralMessage"
                            placeholder="Introduce yourself and explain why you are interested in this position..."
                            required
                        ></textarea>

                    </div>


                    <button
                        type="submit"
                        class="primary-button full-width">

                        Send Referral Request

                    </button>

                </form>
            `;

        openModal(html);
    } catch (error) {
        handleApiError(error);
    }
}

async function submitReferralRequest(event) {
    event.preventDefault();

    const alumniId = document.getElementById("referralAlumni")?.value;
    const company = document.getElementById("referralCompany")?.value.trim();
    const position = document.getElementById("referralPosition")?.value.trim();
    const cvLink = document.getElementById("referralCvLink")?.value.trim();
    const portfolioLink = document.getElementById("referralPortfolioLink")?.value.trim();
    const message = document.getElementById("referralMessage")?.value.trim();

    if (!alumniId || !company || !position || !cvLink || !message) {
        showToast("Please fill all required fields.");
        return;
    }

    try {
        await apiRequest("referrals.php", {
            method: "POST",
            data: {
                action: "create",
                alumni_id: alumniId,
                company,
                position,
                cv_link: cvLink,
                portfolio_link: portfolioLink,
                message
            }
        });

        closeModal();
        showToast("Referral request submitted successfully.");
        loadStudentReferrals();
        loadStudentDashboard();
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   STUDENT REFERRALS
   ========================================================= */
async function loadStudentReferrals() {
    const container = document.getElementById("studentReferralList");
    if (!container) return;

    const student = getCurrentUser();
    if (!student || student.role !== "student") return;

    try {
        const result = await apiRequest("get_referrals.php");
        const referrals = result.referrals;

        if (referrals.length === 0) {
            container.innerHTML = `<div class="empty-state"><div class="empty-state-icon">📄</div>No referral requests sent yet.</div>`;
            return;
        }

        container.innerHTML = referrals.map(r => `
            <div class="referral-card">
                <div class="referral-card-header">
                    <div>
                        <h3>${escapeHTML(r.position)} at ${escapeHTML(r.company)}</h3>
                        <p>Requested to <strong>${escapeHTML(r.alumni_name || "Alumni")}</strong></p>
                    </div>
                    <span class="status status-${escapeHTML(r.status)}">${capitalize(r.status)}</span>
                </div>
                ${safeUrl(r.cv_link) ? `<a href="${safeUrl(r.cv_link)}" target="_blank" rel="noopener noreferrer" class="referral-job-link">📄 View CV</a><br>` : ""}
                ${safeUrl(r.portfolio_link) ? `<a href="${safeUrl(r.portfolio_link)}" target="_blank" rel="noopener noreferrer" class="referral-job-link">🔗 View Portfolio/GitHub</a><br>` : ""}
                <br>
                <div class="referral-message">
                    <strong>Message:</strong>
                    ${escapeHTML(r.message)}
                </div>
                ${r.status === "referred" ? `
                    <div class="referral-success-box">
                        <strong>🎉 Referral Submitted by Alumni!</strong>
                        ${r.proof_note ? `<p style="margin-top:4px;">${escapeHTML(r.proof_note)}</p>` : ""}
                        ${safeUrl(r.proof_link) ? `<p style="margin-top:4px;"><a href="${safeUrl(r.proof_link)}" target="_blank" rel="noopener noreferrer" style="color:#15803d; font-weight:700;">View Referral Confirmation Link</a></p>` : ""}
                    </div>
                ` : ""}
            </div>
        `).join("");
    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `<div class="empty-state">${escapeHTML(error.message || "Failed to load referral requests.")}</div>`;
    }
}

/* =========================================================
   ALUMNI REFERRALS
   ========================================================= */
async function loadAlumniReferrals() {
    const container = document.getElementById("alumniReferralList");
    if (!container) return;

    const alumni = getCurrentUser();
    if (!alumni || alumni.role !== "alumni") return;

    try {
        const result = await apiRequest("get_referrals.php");
        alumniReferralCache = result.referrals;

        if (alumniReferralCache.length === 0) {
            container.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🤝</div><h3>No referral requests yet</h3></div>`;
            return;
        }

        container.innerHTML = alumniReferralCache.map(r => createAlumniReferralCard(r)).join("");
    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `<div class="empty-state">${escapeHTML(error.message || "Failed to load referral requests.")}</div>`;
    }
}

function createAlumniReferralCard(referral) {
    const id = Number(referral.referral_id);

    return `
        <div class="referral-card">
            <div class="referral-card-header">
                <div class="referral-user">
                    <div class="referral-avatar">${escapeHTML(getInitials(referral.student_name || "Student"))}</div>
                    <div>
                        <h3>${escapeHTML(referral.student_name || "Student")}</h3>
                        <p>${escapeHTML(referral.student_department || "Student")}</p>
                    </div>
                </div>
                <span class="status status-${escapeHTML(referral.status)}">${capitalize(referral.status)}</span>
            </div>
            <div class="referral-details">
                <div class="referral-detail">
                    <span class="referral-detail-label">Position</span>
                    <span class="referral-detail-value">${escapeHTML(referral.position)}</span>
                </div>
                <div class="referral-detail">
                    <span class="referral-detail-label">Company</span>
                    <span class="referral-detail-value">${escapeHTML(referral.company)}</span>
                </div>
            </div>
            ${safeUrl(referral.cv_link) ? `<a href="${safeUrl(referral.cv_link)}" target="_blank" rel="noopener noreferrer" class="referral-job-link">📄 View CV</a><br>` : ""}
            ${safeUrl(referral.portfolio_link) ? `<a href="${safeUrl(referral.portfolio_link)}" target="_blank" rel="noopener noreferrer" class="referral-job-link">🔗 View Portfolio/GitHub</a><br>` : ""}
            <br>
            <div class="referral-message">
                <strong>Message:</strong>
                ${escapeHTML(referral.message)}
            </div>
            ${referral.status === "pending" ? `
                <div class="referral-actions">
                    <button class="success-button" onclick="openReferralSubmitModal(${id})">Accept & Submit Referral</button>
                    <button class="danger-button" onclick="updateReferralStatus(${id}, 'declined')">Decline</button>
                </div>
            ` : ""}
        </div>
    `;
}

async function updateReferralStatus(referralId, newStatus) {
    // The only status change an alumni can make without proof is "declined".
    if (newStatus !== "declined") return;

    try {
        await apiRequest("referrals.php", {
            method: "POST",
            data: { action: "decline", referral_id: referralId }
        });

        showToast(`Referral status updated to ${newStatus}.`);
        loadAlumniReferrals();
        loadAlumniDashboard();
        updateAllNotifications();
    } catch (error) {
        handleApiError(error);
        loadAlumniReferrals();
    }
}

function openReferralSubmitModal(referralId) {
    const referral = alumniReferralCache.find(r => Number(r.referral_id) === Number(referralId));
    if (!referral) {
        showToast("Referral request not found. Please refresh the page.");
        return;
    }

    const html = `
        <h2 class="modal-title">Mark Referral as Submitted</h2>
        <p class="modal-subtitle">Provide details or proof for referring ${escapeHTML(referral.position)} at ${escapeHTML(referral.company)}</p>
        <form onsubmit="submitReferralProof(event, ${Number(referralId)})">
            <div class="form-group">
                <label>Notes / Message to Student</label>
                <textarea id="referralProofNote" placeholder="e.g. Submitted your resume internally via employee portal." required></textarea>
            </div>
            <div class="form-group">
                <label>Proof Link <span style="font-weight:400; color:#6b7280;">(Optional)</span></label>
                <input type="url" id="referralProofLink" placeholder="https://company.portal/referral-id">
            </div>
            <button type="submit" class="primary-button full-width">Confirm Referral</button>
        </form>
    `;
    openModal(html);
}

async function submitReferralProof(event, referralId) {
    event.preventDefault();

    const proofNote = document.getElementById("referralProofNote")?.value.trim() || "";
    const proofLink = document.getElementById("referralProofLink")?.value.trim() || "";

    if (!proofNote) {
        showToast("Please provide referral details.");
        return;
    }

    try {
        await apiRequest("referrals.php", {
            method: "POST",
            data: { action: "submit", referral_id: referralId, proof_note: proofNote, proof_link: proofLink }
        });

        closeModal();
        showToast("Referral submitted successfully.");
        loadAlumniReferrals();
        loadAlumniDashboard();
        updateAllNotifications();
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   STUDENT PROFILE
   ========================================================= */
function fillStudentProfileForm(student) {
    const fields = {
        studentProfileName: student.name,
        studentProfileEmail: student.email,
        studentProfileDepartment: student.department,
        studentProfileSkills: student.skills,
        studentProfileCvLink: student.cv_link,
        studentProfilePortfolioLink: student.portfolio_link
    };

    Object.entries(fields).forEach(([id, value]) => {
        const input = document.getElementById(id);
        if (input) input.value = value || "";
    });
}

async function loadStudentProfile() {
    if (currentUser?.role !== "student") return;

    try {
        const result = await apiRequest("student_profile.php");
        currentUser = result.student;
        fillStudentProfileForm(currentUser);
        applyUserToHeader();
    } catch (error) {
        handleApiError(error);
    }
}

async function updateStudentProfile(event) {
    event.preventDefault();

    try {
        const result = await apiRequest("student_profile.php", {
            method: "POST",
            data: {
                name: document.getElementById("studentProfileName").value.trim(),
                department: document.getElementById("studentProfileDepartment").value.trim(),
                skills: document.getElementById("studentProfileSkills").value.trim(),
                cv_link: document.getElementById("studentProfileCvLink").value.trim(),
                portfolio_link: document.getElementById("studentProfilePortfolioLink").value.trim()
            }
        });

        // Show exactly what MySQL now contains.
        currentUser = result.student;
        fillStudentProfileForm(currentUser);
        applyUserToHeader();
        showToast("Profile updated successfully!");
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   ALUMNI PROFILE
   ========================================================= */
function fillAlumniProfileForm(alumni) {
    const fields = {
        alumniProfileName: alumni.name,
        alumniProfileEmail: alumni.email,
        alumniProfileCompany: alumni.company,
        alumniProfileJob: alumni.job_title,
        alumniProfileSkills: alumni.skills,
        alumniProfileBio: alumni.bio,
        alumniProfileLinkedinLink: alumni.linkedin_link,
        alumniProfilePortfolioLink: alumni.portfolio_link
    };

    Object.entries(fields).forEach(([id, value]) => {
        const input = document.getElementById(id);

        if (input) {
            input.value = value || "";
        }
    });
}

async function loadAlumniProfile() {
    if (currentUser?.role !== "alumni") return;

    try {
        const result = await apiRequest("alumni_profile.php");
        currentUser = result.alumni;
        fillAlumniProfileForm(currentUser);
        applyUserToHeader();
    } catch (error) {
        handleApiError(error);
    }
}

async function updateAlumniProfile(event) {
    event.preventDefault();

    try {
        const result = await apiRequest("alumni_profile.php", {
            method: "POST",
            data: {
                name: document.getElementById("alumniProfileName").value.trim(),

                company: document
                    .getElementById("alumniProfileCompany")
                    .value
                    .trim(),

                job_title: document
                    .getElementById("alumniProfileJob")
                    .value
                    .trim(),

                skills: document
                    .getElementById("alumniProfileSkills")
                    .value
                    .trim(),

                bio: document
                    .getElementById("alumniProfileBio")
                    .value
                    .trim(),

                linkedin_link: document
                    .getElementById("alumniProfileLinkedinLink")
                    .value
                    .trim(),

                portfolio_link: document
                    .getElementById("alumniProfilePortfolioLink")
                    .value
                    .trim()
            }
        });

        currentUser = result.alumni;

        fillAlumniProfileForm(currentUser);
        applyUserToHeader();

        showToast("Profile updated successfully!");

    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   NOTIFICATIONS (stored in the MySQL "notifications" table;
   created by the server when something happens)
   ========================================================= */
async function updateAllNotifications() {
    const user = getCurrentUser();
    if (!user) return;

    try {
        const result = await apiRequest("notifications.php");

        // The user may have logged out / switched account while the request was running.
        if (currentUser !== user && (currentUser?.role !== user.role || currentUser?.id !== user.id)) return;

        renderNotifications(user.role, result.notifications, result.unread_count);
    } catch (error) {
        if (!error.handled) console.error("Notifications error:", error);
    }
}

function renderNotifications(role, notifications, unreadCount) {
    const badge = document.getElementById(`${role}NotificationBadge`);
    const list = document.getElementById(`${role}NotificationList`);
    if (!badge || !list) return;

    unreadNotificationCount = unreadCount;

    if (unreadCount > 0) {
        badge.textContent = unreadCount;
        badge.classList.remove("hidden");
    } else {
        badge.classList.add("hidden");
    }

    if (notifications.length === 0) {
        list.innerHTML = `<div class="notification-item" style="text-align:center; color:#6b7280;">No notifications yet.</div>`;
        return;
    }

    list.innerHTML = notifications.map(n => `
        <div class="notification-item ${!Number(n.is_read) ? "unread" : ""}">
            <strong>${escapeHTML(n.title)}</strong>
            <p>${escapeHTML(n.message)}</p>
            <span class="notification-time">${formatNotificationTime(n.created_at)}</span>
        </div>
    `).join("");
}

// Keeps the bell up to date when the other user does something (every 30 s).
function startNotificationPolling() {
    clearInterval(notificationTimer);
    notificationTimer = setInterval(() => {
        if (currentUser) updateAllNotifications();
    }, 30000);
}

async function toggleNotifications(role) {
    const panel = document.getElementById(`${role}NotificationPanel`);
    if (!panel) return;

    panel.classList.toggle("show");
    if (panel.classList.contains("show")) {
        await updateAllNotifications();   // show the newest first...
        markNotificationsAsRead();        // ...then mark them read (like the original behaviour)
    }
}

async function markNotificationsAsRead() {
    const user = getCurrentUser();
    if (!user || unreadNotificationCount === 0) return;

    try {
        await apiRequest("notifications.php", { method: "POST", data: { action: "mark_all_read" } });

        unreadNotificationCount = 0;
        document.getElementById(`${user.role}NotificationBadge`)?.classList.add("hidden");
    } catch (error) {
        handleApiError(error);
    }
}

async function clearNotifications(role) {
    if (!getCurrentUser()) return;

    try {
        await apiRequest("notifications.php", { method: "POST", data: { action: "clear_all" } });
        updateAllNotifications();
    } catch (error) {
        handleApiError(error);
    }
}

/* =========================================================
   MODAL LOGIC
   ========================================================= */
function openModal(htmlContent) {
    const modal = document.getElementById("modal");
    const modalBody = document.getElementById("modalBody");
    if (!modal || !modalBody) return;
    modalBody.innerHTML = htmlContent;
    modal.classList.remove("hidden");
}

function closeModal() {
    const modal = document.getElementById("modal");
    if (modal) modal.classList.add("hidden");
}

window.addEventListener("click", (event) => {
    const modal = document.getElementById("modal");
    if (event.target === modal) {
        closeModal();
    }
});

/* =========================================================
   INITIALIZATION
   Ask the server who is logged in (PHP session) - the browser
   itself is never trusted to remember the user.
   ========================================================= */
window.addEventListener("DOMContentLoaded", async () => {
    try {
        const result = await apiRequest("auth.php?action=current_user", { skipAuthRedirect: true });

        if (result.authenticated && result.user) {
            enterApp(result.user);
            return;
        }
    } catch (error) {
        handleApiError(error);
    }

    document.getElementById("authPage")?.classList.remove("hidden");
    showRoleSelection();
});
