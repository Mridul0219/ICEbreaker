<?php
/*
 * GET  student_profile.php  -> the logged-in student's profile
 * POST student_profile.php  -> update it
 * The student is identified by the PHP session, never by an id sent from the browser.
 */

require_once "helpers.php";

$auth = require_auth("student");
$student_id = $auth["id"];

if ($_SERVER["REQUEST_METHOD"] === "GET") {

    $profile = fetch_profile($conn, "student", $student_id);
    if (!$profile) {
        throw new ApiException("Profile not found.", 404);
    }
    json_response(["success" => true, "student" => user_payload($profile, "student")]);
}

require_method("POST");

$name = post_string("name", 100);
$department = empty_to_null(post_string("department", 100));
$skills = empty_to_null(post_string("skills", 1000));
$cv_link = optional_url(post_string("cv_link", 500), "CV link");
$portfolio_link = optional_url(post_string("portfolio_link", 500), "Portfolio link");

if ($name === "") {
    throw new ApiException("Name is required.", 400);
}

$stmt = $conn->prepare(
    "UPDATE students
     SET name = ?, department = ?, skills = ?, cv_link = ?, portfolio_link = ?
     WHERE student_id = ?"
);
$stmt->bind_param("sssssi", $name, $department, $skills, $cv_link, $portfolio_link, $student_id);
$stmt->execute();
$stmt->close();

$profile = fetch_profile($conn, "student", $student_id);

json_response([
    "success" => true,
    "message" => "Profile updated successfully",
    "student" => user_payload($profile, "student")
]);
