<?php
/*
 * POST referrals.php  action=create   (student)  alumni_id, company, position, cv_link, [portfolio_link], message
 * POST referrals.php  action=decline  (alumni)   referral_id
 * POST referrals.php  action=submit   (alumni)   referral_id, proof_note, [proof_link]
 *
 * The acting user always comes from the PHP session; an alumni can only
 * change referral requests addressed to them.
 */

require_once "helpers.php";

require_method("POST");
$action = post_string("action", 20);


/* =========================================================
   CREATE REFERRAL REQUEST  (student)
   ========================================================= */
if ($action === "create") {

    $auth = require_auth("student");
    $student_id = $auth["id"];

    $alumni_id = post_int("alumni_id");
    $company = post_string("company", 150);
    $position = post_string("position", 150);
    $cv_link = post_string("cv_link", 500);
    $portfolio_link = post_string("portfolio_link", 500);
    $message = post_string("message", 2000);

    if (!$alumni_id || $company === "" || $position === "" || $cv_link === "" || $message === "") {
        throw new ApiException("Please fill all required fields", 400);
    }

    $cv_link = optional_url($cv_link, "CV link");
    $portfolio_link = optional_url($portfolio_link, "Portfolio link");

    $referral_id = with_transaction($conn, function () use (
        $conn, $student_id, $alumni_id, $company, $position, $cv_link, $portfolio_link, $message
    ) {
        // The alumni must exist.
        $stmt = $conn->prepare("SELECT alumni_id FROM alumni WHERE alumni_id = ?");
        $stmt->bind_param("i", $alumni_id);
        $stmt->execute();
        $found = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if (!$found) {
            throw new ApiException("Selected alumni was not found.", 404);
        }

        $stmt = $conn->prepare(
            "INSERT INTO referral_requests
                (student_id, alumni_id, company, position, cv_link, portfolio_link, message, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')"
        );
        $stmt->bind_param(
            "iisssss",
            $student_id, $alumni_id, $company, $position, $cv_link, $portfolio_link, $message
        );
        $stmt->execute();
        $newId = $stmt->insert_id;
        $stmt->close();

        add_notification(
            $conn,
            "alumni",
            $alumni_id,
            "New Referral Request",
            display_name($conn, "student", $student_id)
                . " requested a referral for $position at $company."
        );

        return $newId;
    });

    json_response([
        "success" => true,
        "message" => "Referral request submitted successfully",
        "referral_id" => $referral_id
    ]);
}


/* =========================================================
   DECLINE REFERRAL  (alumni)
   ========================================================= */
if ($action === "decline") {

    $auth = require_auth("alumni");
    $alumni_id = $auth["id"];

    $referral_id = post_int("referral_id");
    if (!$referral_id) {
        throw new ApiException("Missing referral information", 400);
    }

    with_transaction($conn, function () use ($conn, $alumni_id, $referral_id) {

        $stmt = $conn->prepare(
            "SELECT student_id, company, position
             FROM referral_requests
             WHERE referral_id = ? AND alumni_id = ? AND status = 'pending'
             FOR UPDATE"
        );
        $stmt->bind_param("ii", $referral_id, $alumni_id);
        $stmt->execute();
        $referral = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$referral) {
            throw new ApiException("Referral request could not be declined", 404);
        }

        $stmt = $conn->prepare(
            "UPDATE referral_requests SET status = 'declined'
             WHERE referral_id = ? AND alumni_id = ? AND status = 'pending'"
        );
        $stmt->bind_param("ii", $referral_id, $alumni_id);
        $stmt->execute();
        $stmt->close();

        add_notification(
            $conn,
            "student",
            (int)$referral["student_id"],
            "Referral Status: Declined",
            display_name($conn, "alumni", $alumni_id)
                . " updated your referral status for {$referral['position']} at {$referral['company']} to declined."
        );
    });

    json_response(["success" => true, "message" => "Referral request declined"]);
}


/* =========================================================
   SUBMIT REFERRAL  (alumni)
   ========================================================= */
if ($action === "submit") {

    $auth = require_auth("alumni");
    $alumni_id = $auth["id"];

    $referral_id = post_int("referral_id");
    $proof_note = post_string("proof_note", 2000);
    $proof_link = optional_url(post_string("proof_link", 500), "Proof link");

    if (!$referral_id || $proof_note === "") {
        throw new ApiException("Please provide referral details", 400);
    }

    with_transaction($conn, function () use ($conn, $alumni_id, $referral_id, $proof_note, $proof_link) {

        $stmt = $conn->prepare(
            "SELECT student_id, company, position
             FROM referral_requests
             WHERE referral_id = ? AND alumni_id = ? AND status = 'pending'
             FOR UPDATE"
        );
        $stmt->bind_param("ii", $referral_id, $alumni_id);
        $stmt->execute();
        $referral = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$referral) {
            throw new ApiException("Referral could not be submitted", 404);
        }

        $stmt = $conn->prepare(
            "UPDATE referral_requests
             SET status = 'referred', proof_note = ?, proof_link = ?
             WHERE referral_id = ? AND alumni_id = ? AND status = 'pending'"
        );
        $stmt->bind_param("ssii", $proof_note, $proof_link, $referral_id, $alumni_id);
        $stmt->execute();
        $stmt->close();

        add_notification(
            $conn,
            "student",
            (int)$referral["student_id"],
            "Referral Submitted 🎉",
            display_name($conn, "alumni", $alumni_id)
                . " submitted a referral for {$referral['position']} at {$referral['company']}."
        );
    });

    json_response(["success" => true, "message" => "Referral submitted successfully"]);
}

throw new ApiException("Invalid action.", 400);
