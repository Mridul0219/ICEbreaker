<?php
/*
 * GET  notifications.php                          -> my notifications + unread_count
 * POST notifications.php action=mark_read         notification_id
 * POST notifications.php action=mark_all_read
 * POST notifications.php action=clear_all         (the "Clear All" button)
 *
 * Notifications are CREATED by the server (sessions.php, referrals.php,
 * availability.php) in the same transaction as the action itself.
 * A user can only see / change notifications that belong to them.
 */

require_once "helpers.php";

$auth = require_auth();

// Column name comes from this fixed mapping, never from user input.
$ownerColumn = $auth["role"] === "student" ? "student_id" : "alumni_id";
$userId = $auth["id"];

if ($_SERVER["REQUEST_METHOD"] === "GET") {

    $stmt = $conn->prepare(
        "SELECT notification_id, title, message, is_read, created_at
         FROM notifications
         WHERE $ownerColumn = ?
         ORDER BY created_at DESC, notification_id DESC
         LIMIT 100"
    );
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $unread = 0;
    foreach ($notifications as &$n) {
        $n["is_read"] = (int)$n["is_read"];
        if (!$n["is_read"]) {
            $unread++;
        }
    }
    unset($n);

    json_response([
        "success" => true,
        "notifications" => $notifications,
        "unread_count" => $unread
    ]);
}

require_method("POST");
$action = post_string("action", 20);

if ($action === "mark_read") {

    $id = post_int("notification_id");
    if (!$id) {
        throw new ApiException("Invalid notification.", 400);
    }

    $stmt = $conn->prepare(
        "UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND $ownerColumn = ?"
    );
    $stmt->bind_param("ii", $id, $userId);
    $stmt->execute();
    $stmt->close();

    json_response(["success" => true, "message" => "Notification marked as read"]);
}

if ($action === "mark_all_read") {

    $stmt = $conn->prepare(
        "UPDATE notifications SET is_read = 1 WHERE $ownerColumn = ? AND is_read = 0"
    );
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->close();

    json_response(["success" => true, "message" => "All notifications marked as read"]);
}

if ($action === "clear_all") {

    $stmt = $conn->prepare("DELETE FROM notifications WHERE $ownerColumn = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->close();

    json_response(["success" => true, "message" => "Notifications cleared"]);
}

throw new ApiException("Invalid action.", 400);
