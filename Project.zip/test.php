<?php
/* Development helper only - delete this file before deploying anywhere public. */

require_once "db.php";

echo "Database connected successfully!";
