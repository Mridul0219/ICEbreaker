<?php
/*
 * Database connection (MySQL / MariaDB).
 * Same approach as before (mysqli, root, no password, alumni_bridge),
 * but with strict error reporting and controlled JSON errors instead of die().
 */

$host = "localhost";
$username = "root";
$password = "";
$database = "alumni_bridge";

// Throw exceptions on SQL errors (caught centrally in helpers.php).
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($host, $username, $password, $database);
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    // Log the real reason, show the user nothing sensitive.
    error_log("AlumniBridge DB connection failed: " . $e->getMessage());
    if (!headers_sent()) {
        http_response_code(500);
        header("Content-Type: application/json; charset=utf-8");
    }
    echo json_encode([
        "success" => false,
        "message" => "The database is currently unavailable."
    ]);
    exit;
}
