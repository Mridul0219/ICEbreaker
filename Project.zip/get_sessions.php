<?php
/*
 * GET get_sessions.php
 * Returns the sessions of whoever is logged in (student: their requests,
 * alumni: requests addressed to them). role/user_id in the URL are ignored.
 */

require_once "helpers.php";

$auth = require_auth();

if ($auth["role"] === "student") {

    $stmt = $conn->prepare(
        "SELECT s.session_id, s.alumni_id, s.availability_id, s.topic, s.message,
                s.session_date, s.start_time, s.end_time, s.status, s.created_at,
                a.name AS alumni_name,
                a.company AS alumni_company,
                a.job_title AS alumni_job_title
         FROM sessions s
         INNER JOIN alumni a ON s.alumni_id = a.alumni_id
         WHERE s.student_id = ?
         ORDER BY s.created_at DESC, s.session_id DESC"
    );

} else {

    $stmt = $conn->prepare(
        "SELECT s.session_id, s.student_id, s.availability_id, s.topic, s.message,
                s.session_date, s.start_time, s.end_time, s.status, s.created_at,
                st.name AS student_name,
                st.department AS student_department
         FROM sessions s
         INNER JOIN students st ON s.student_id = st.student_id
         WHERE s.alumni_id = ?
         ORDER BY s.created_at DESC, s.session_id DESC"
    );
}

$stmt->bind_param("i", $auth["id"]);
$stmt->execute();
$sessions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

json_response(["success" => true, "sessions" => $sessions]);
