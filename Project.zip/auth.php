<?php
/*
 * Authentication endpoint.
 *
 *   POST auth.php  action=login            role, email, password
 *   POST auth.php  action=logout
 *   GET  auth.php?action=current_user      (alias: check_session)
 *   POST auth.php  action=forgot_password  email
 *
 * The logged-in user lives in the PHP session ($_SESSION["role"], $_SESSION["user_id"]).
 * The browser only ever receives safe profile data (never the password hash).
 */

require_once "helpers.php";

$action = $_POST["action"] ?? $_GET["action"] ?? "";

/* ---------- who is logged in? ---------- */
if ($action === "current_user" || $action === "check_session") {

    $auth = current_auth();
    $profile = $auth ? fetch_profile($conn, $auth["role"], $auth["id"]) : null;

    if (!$profile) {
        // Session points to a deleted account (or nobody is logged in).
        if ($auth) {
            $_SESSION = [];
            session_destroy();
        }
        json_response(["success" => true, "authenticated" => false, "user" => null]);
    }

    json_response([
        "success" => true,
        "authenticated" => true,
        "user" => user_payload($profile, $auth["role"])
    ]);
}

require_method("POST");

/* ---------- login ---------- */
if ($action === "login") {

    $role = post_string("role", 10);
    $email = strtolower(post_string("email", 150));
    $password = (string)($_POST["password"] ?? "");

    if ($email === "" || $password === "") {
        throw new ApiException("Please enter email and password.", 400);
    }

    $profile = login_user($conn, $role, $email, $password);

    if (!$profile) {
        throw new ApiException("Invalid email or password", 401);
    }

    json_response([
        "success" => true,
        "message" => "Logged in successfully.",
        "user" => user_payload($profile, $role)
    ]);
}

/* ---------- logout ---------- */
if ($action === "logout") {

    $_SESSION = [];

    if (ini_get("session.use_cookies")) {
        $p = session_get_cookie_params();
        setcookie(session_name(), "", time() - 3600, $p["path"], $p["domain"], $p["secure"], $p["httponly"]);
    }
    session_destroy();

    json_response(["success" => true, "message" => "Logged out successfully."]);
}

/* ---------- forgot password ----------
 * There is no mail server in this project, so no email is actually sent.
 * The response is intentionally the same whether or not the address exists,
 * so the form cannot be used to discover which emails have accounts.
 */
if ($action === "forgot_password") {

    $email = strtolower(post_string("email", 150));

    if (!valid_email($email)) {
        throw new ApiException("Please enter a valid email address.", 400);
    }

    json_response([
        "success" => true,
        "message" => "If an account exists for this email, reset instructions will be sent."
    ]);
}

throw new ApiException("Invalid action.", 400);
