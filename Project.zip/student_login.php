<?php
/* Kept for compatibility. The frontend now uses auth.php?action=login,
   but this endpoint works the same way and also starts the PHP session. */

require_once "helpers.php";
require_method("POST");

$email = strtolower(post_string("email", 150));
$password = (string)($_POST["password"] ?? "");

$student = login_user($conn, "student", $email, $password);

if (!$student) {
    throw new ApiException("Invalid email or password", 401);
}

json_response(["success" => true, "student" => $student]);
