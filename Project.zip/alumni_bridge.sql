-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 09:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumni_bridge`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `alumni_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `company` varchar(150) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `linkedin_link` varchar(500) DEFAULT NULL,
  `portfolio_link` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`alumni_id`, `name`, `email`, `password`, `job_title`, `company`, `skills`, `bio`, `linkedin_link`, `portfolio_link`, `created_at`) VALUES
(1, 'Riyadh', 'riyad@gmail.com', '$2y$10$gO3yNp.dDUTeDX/JHG26bOlTveIpIIqjPsdwt0ZpybSqTYOfbg7Zu', 'Senior Software Developer', 'BrainStation', 'Python, React', 'Hello', NULL, NULL, '2026-09-27 16:48:53'),
(2, 'Samir', 'samir@gmail.com', '$2y$10$EsQ8aDRRHX.ixXxCn3o5SOiS2tBRZn3YY0yUNpiqaT3oYUjWNNeXi', 'Data Scientist', 'BrainStation', 'Python, Power BI', 'checking', 'https://www.linkedin.com/in/anasahmed-?utm_source=..', 'https://www.linkedin.com/in/anasahmed-?utm_source=..', '2026-09-27 16:59:06'),
(3, 'saad', 'saad@gmail.com', '$2y$10$JKezAAbKo5CmHRsNxPgpH.hNMCKj6r6i5rrUC.DBovQn.nNvkJzxO', 'Data Scientist', 'BrainStation', 'Python, Power BI', 'great!', NULL, NULL, '2026-09-27 20:54:52');

-- --------------------------------------------------------

--
-- Table structure for table `availability`
--

CREATE TABLE `availability` (
  `availability_id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `available_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `status` enum('available','booked','cancelled') DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `availability`
--

INSERT INTO `availability` (`availability_id`, `alumni_id`, `available_date`, `start_time`, `end_time`, `status`) VALUES
(2, 2, '2026-09-29', '10:55:00', '11:55:00', 'available'),
(3, 2, '2026-10-10', '00:57:00', '01:27:00', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `alumni_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `student_id`, `alumni_id`, `title`, `message`, `is_read`, `created_at`) VALUES
(1, NULL, 1, 'New Referral Request', 'Anas Ahmed requested a referral for software engineer at Google.', 1, '2026-09-28 12:29:58'),
(2, 1, NULL, 'Referral Submitted 🎉', 'riyad submitted a referral for software engineer at Google.', 1, '2026-09-28 12:31:15');

-- --------------------------------------------------------

--
-- Table structure for table `referral_requests`
--

CREATE TABLE `referral_requests` (
  `referral_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `company` varchar(150) NOT NULL,
  `position` varchar(150) NOT NULL,
  `cv_link` varchar(500) NOT NULL,
  `portfolio_link` varchar(500) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('pending','declined','referred') DEFAULT 'pending',
  `proof_note` text DEFAULT NULL,
  `proof_link` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `referral_requests`
--

INSERT INTO `referral_requests` (`referral_id`, `student_id`, `alumni_id`, `company`, `position`, `cv_link`, `portfolio_link`, `message`, `status`, `proof_note`, `proof_link`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Google', 'software engineer', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', 'i want to go to google. Your guidance would be appreciated', 'referred', 'Done', NULL, '2026-09-28 12:29:58', '2026-09-28 12:31:15');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `session_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `availability_id` int(11) DEFAULT NULL,
  `topic` varchar(200) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `session_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `status` enum('pending','confirmed','cancelled','declined') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`session_id`, `student_id`, `alumni_id`, `availability_id`, `topic`, `message`, `session_date`, `start_time`, `end_time`, `status`, `created_at`) VALUES
(1, 2, 2, 2, NULL, 'about software engineering', '2026-09-29', '10:55:00', '11:55:00', 'confirmed', '2026-09-27 22:58:23'),
(2, 2, 2, 3, NULL, 'please', '2026-10-10', '00:57:00', '01:27:00', 'cancelled', '2026-09-27 23:07:42');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `cv_link` varchar(500) DEFAULT NULL,
  `portfolio_link` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `name`, `email`, `password`, `department`, `skills`, `cv_link`, `portfolio_link`, `created_at`) VALUES
(1, 'Anas Ahmed', 'anas@gmail.com', '$2y$10$q7oleVfxiMYOjivs4n5Ki.7oSbOsOwR6WcOIS9BqET3XlRmBg528a', 'CSE', 'Python', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', '2026-09-27 11:21:30'),
(2, 'sajid', 'sajid@gmail.com', '$2y$10$v6HVEHX/NxKtjqjWW0F3v.j9Z40VlsKJWeoPo2.ZfF5DlHc040k3u', 'CSE', 'React,css', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', '', '2026-09-27 11:23:23'),
(3, 'siam', 'siam@gmail.com', '$2y$10$gy5cLmymJgF474W1gvfrHuqEjRlO4oAoKyt9n.PIHuRlfedhhwvkS', 'BBA', 'MS WORD, EXCEL', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', 'https://www.linkedin.com/in/anasahmed-?utm_source=share_via&utm_content=profile&utm_medium=member_android', '2026-09-27 11:28:56'),
(4, 'salim', 'salim@gmail.com', '$2y$10$iT9lqUz4NbxwvWEd8GRuzutFy1Mj5JPhQ385.cHBDRZ23vsWDMPu.', NULL, NULL, NULL, NULL, '2026-09-27 16:20:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`alumni_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `availability`
--
ALTER TABLE `availability`
  ADD PRIMARY KEY (`availability_id`),
  ADD KEY `alumni_id` (`alumni_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `alumni_id` (`alumni_id`);

--
-- Indexes for table `referral_requests`
--
ALTER TABLE `referral_requests`
  ADD PRIMARY KEY (`referral_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `alumni_id` (`alumni_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `alumni_id` (`alumni_id`),
  ADD KEY `availability_id` (`availability_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alumni`
--
ALTER TABLE `alumni`
  MODIFY `alumni_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `availability`
--
ALTER TABLE `availability`
  MODIFY `availability_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `referral_requests`
--
ALTER TABLE `referral_requests`
  MODIFY `referral_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `availability`
--
ALTER TABLE `availability`
  ADD CONSTRAINT `availability_ibfk_1` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`alumni_id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`alumni_id`) ON DELETE CASCADE;

--
-- Constraints for table `referral_requests`
--
ALTER TABLE `referral_requests`
  ADD CONSTRAINT `referral_requests_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `referral_requests_ibfk_2` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`alumni_id`) ON DELETE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`alumni_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sessions_ibfk_3` FOREIGN KEY (`availability_id`) REFERENCES `availability` (`availability_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
