<?php
/*
 * GET  alumni_profile.php  -> the logged-in alumni's profile
 * POST alumni_profile.php  -> update it
 * The alumni is identified by the PHP session, never by an id sent from the browser.
 */

require_once "helpers.php";

$auth = require_auth("alumni");
$alumni_id = $auth["id"];

if ($_SERVER["REQUEST_METHOD"] === "GET") {

    $profile = fetch_profile($conn, "alumni", $alumni_id);
    if (!$profile) {
        throw new ApiException("Profile not found.", 404);
    }
    json_response(["success" => true, "alumni" => user_payload($profile, "alumni")]);
}

require_method("POST");

$name = post_string("name", 100);
$company = empty_to_null(post_string("company", 150));
$job_title = empty_to_null(post_string("job_title", 100));
$skills = empty_to_null(post_string("skills", 1000));
$bio = empty_to_null(post_string("bio", 2000));

$linkedin_link = optional_url(
    post_string("linkedin_link", 500),
    "LinkedIn link"
);

$portfolio_link = optional_url(
    post_string("portfolio_link", 500),
    "Portfolio / GitHub link"
);

if ($name === "") {
    throw new ApiException("Name is required.", 400);
}

$stmt = $conn->prepare(
    "UPDATE alumni
     SET name = ?,
         company = ?,
         job_title = ?,
         skills = ?,
         bio = ?,
         linkedin_link = ?,
         portfolio_link = ?
     WHERE alumni_id = ?"
);

$stmt->bind_param(
    "sssssssi",
    $name,
    $company,
    $job_title,
    $skills,
    $bio,
    $linkedin_link,
    $portfolio_link,
    $alumni_id
);
$stmt->execute();
$stmt->close();

$profile = fetch_profile($conn, "alumni", $alumni_id);

json_response([
    "success" => true,
    "message" => "Profile updated successfully",
    "alumni" => user_payload($profile, "alumni")
]);
