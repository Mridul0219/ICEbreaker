<?php
/*
 * POST sessions.php  action=create   (student)  alumni_id, availability_id, message
 * POST sessions.php  action=accept   (alumni)   session_id
 * POST sessions.php  action=decline  (alumni)   session_id
 * POST sessions.php  action=cancel   (student or alumni)  session_id, [reason]
 *
 * Who is acting always comes from the PHP session. Every UPDATE is restricted
 * to rows that belong to that user.
 *
 * Booking rules (kept from the original project):
 *   - Several students may REQUEST the same slot (a request does not book it).
 *   - When the alumni ACCEPTS a request the slot becomes 'booked'; competing
 *     pending requests for that slot are cancelled and their students notified.
 *   - Cancelling a confirmed session re-opens the slot.
 *   - An alumni declining a request sets status 'cancelled' (existing behaviour).
 */

require_once "helpers.php";

require_method("POST");
$action = post_string("action", 20);


/* =========================================================
   CREATE SESSION REQUEST  (student)
   ========================================================= */
if ($action === "create") {

    $auth = require_auth("student");
    $student_id = $auth["id"];

    $alumni_id = post_int("alumni_id");
    $availability_id = post_int("availability_id");
    $message = post_string("message", 2000);

    if (!$alumni_id || !$availability_id || $message === "") {
        throw new ApiException("Missing session information", 400);
    }

    $session_id = with_transaction($conn, function () use ($conn, $student_id, $alumni_id, $availability_id, $message) {

        // Lock the slot: it must exist, belong to the chosen alumni and still be available.
        $stmt = $conn->prepare(
            "SELECT available_date, start_time, end_time
             FROM availability
             WHERE availability_id = ? AND alumni_id = ? AND status = 'available'
             FOR UPDATE"
        );
        $stmt->bind_param("ii", $availability_id, $alumni_id);
        $stmt->execute();
        $slot = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$slot) {
            throw new ApiException("Selected availability slot is not available", 409);
        }

        // Date-only check with one day of tolerance (server and user may be in different time zones).
        if ($slot["available_date"] < date("Y-m-d", strtotime("-1 day"))) {
            throw new ApiException("This time slot is in the past.", 400);
        }

        // Do not allow the same student to request the same slot twice.
        $stmt = $conn->prepare(
            "SELECT 1 FROM sessions
             WHERE student_id = ? AND availability_id = ?
               AND status IN ('pending', 'confirmed') LIMIT 1"
        );
        $stmt->bind_param("ii", $student_id, $availability_id);
        $stmt->execute();
        $duplicate = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($duplicate) {
            throw new ApiException("You already have a request for this time slot.", 409);
        }

        $stmt = $conn->prepare(
            "INSERT INTO sessions
                (student_id, alumni_id, availability_id, topic, message,
                 session_date, start_time, end_time, status)
             VALUES (?, ?, ?, NULL, ?, ?, ?, ?, 'pending')"
        );
        $stmt->bind_param(
            "iiissss",
            $student_id,
            $alumni_id,
            $availability_id,
            $message,
            $slot["available_date"],
            $slot["start_time"],
            $slot["end_time"]
        );
        $stmt->execute();
        $newId = $stmt->insert_id;
        $stmt->close();

        add_notification(
            $conn,
            "alumni",
            $alumni_id,
            "New Mentorship Request",
            display_name($conn, "student", $student_id)
                . " requested a mentorship session on "
                . slot_text($slot["available_date"], $slot["start_time"]) . "."
        );

        return $newId;
    });

    json_response([
        "success" => true,
        "message" => "Mentorship request sent successfully",
        "session_id" => $session_id
    ]);
}


/* =========================================================
   ACCEPT SESSION  (alumni)
   ========================================================= */
if ($action === "accept") {

    $auth = require_auth("alumni");
    $alumni_id = $auth["id"];

    $session_id = post_int("session_id");
    if (!$session_id) {
        throw new ApiException("Invalid session.", 400);
    }

    with_transaction($conn, function () use ($conn, $alumni_id, $session_id) {

        // The session must be addressed to THIS alumni and still be pending.
        $stmt = $conn->prepare(
            "SELECT student_id, availability_id, session_date, start_time
             FROM sessions
             WHERE session_id = ? AND alumni_id = ? AND status = 'pending'
             FOR UPDATE"
        );
        $stmt->bind_param("ii", $session_id, $alumni_id);
        $stmt->execute();
        $session = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$session) {
            throw new ApiException("Session could not be accepted", 404);
        }

        $availability_id = $session["availability_id"] !== null ? (int)$session["availability_id"] : 0;
        $alumniName = display_name($conn, "alumni", $alumni_id);

        if ($availability_id) {

            // Lock the slot so two accepts cannot both succeed.
            $stmt = $conn->prepare(
                "SELECT status FROM availability
                 WHERE availability_id = ? AND alumni_id = ? FOR UPDATE"
            );
            $stmt->bind_param("ii", $availability_id, $alumni_id);
            $stmt->execute();
            $slot = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $stmt = $conn->prepare(
                "SELECT 1 FROM sessions
                 WHERE availability_id = ? AND status = 'confirmed' AND session_id <> ? LIMIT 1"
            );
            $stmt->bind_param("ii", $availability_id, $session_id);
            $stmt->execute();
            $alreadyConfirmed = $stmt->get_result()->num_rows > 0;
            $stmt->close();

            if (!$slot || $slot["status"] !== "available" || $alreadyConfirmed) {
                throw new ApiException("This time slot is no longer available.", 409);
            }

            $stmt = $conn->prepare(
                "UPDATE availability SET status = 'booked' WHERE availability_id = ?"
            );
            $stmt->bind_param("i", $availability_id);
            $stmt->execute();
            $stmt->close();

            // Other students who requested the same slot: cancel + notify.
            $stmt = $conn->prepare(
                "SELECT session_id, student_id FROM sessions
                 WHERE availability_id = ? AND status = 'pending' AND session_id <> ?
                 FOR UPDATE"
            );
            $stmt->bind_param("ii", $availability_id, $session_id);
            $stmt->execute();
            $others = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            if ($others) {
                $upd = $conn->prepare("UPDATE sessions SET status = 'cancelled' WHERE session_id = ?");
                foreach ($others as $o) {
                    $oid = (int)$o["session_id"];
                    $upd->bind_param("i", $oid);
                    $upd->execute();

                    add_notification(
                        $conn,
                        "student",
                        (int)$o["student_id"],
                        "Session Request Cancelled",
                        "The time slot on " . slot_text($session["session_date"], $session["start_time"])
                            . " with $alumniName was booked by another student."
                    );
                }
                $upd->close();
            }
        }

        $stmt = $conn->prepare(
            "UPDATE sessions SET status = 'confirmed'
             WHERE session_id = ? AND alumni_id = ? AND status = 'pending'"
        );
        $stmt->bind_param("ii", $session_id, $alumni_id);
        $stmt->execute();
        $stmt->close();

        add_notification(
            $conn,
            "student",
            (int)$session["student_id"],
            "Session Confirmed",
            "$alumniName accepted your mentorship session on "
                . slot_text($session["session_date"], $session["start_time"]) . "."
        );
    });

    json_response(["success" => true, "message" => "Session accepted"]);
}


/* =========================================================
   DECLINE SESSION  (alumni)
   The original project sets status 'cancelled' when an alumni declines
   a pending request, so that behaviour is kept.
   ========================================================= */
if ($action === "decline") {

    $auth = require_auth("alumni");
    $alumni_id = $auth["id"];

    $session_id = post_int("session_id");
    if (!$session_id) {
        throw new ApiException("Invalid session.", 400);
    }

    with_transaction($conn, function () use ($conn, $alumni_id, $session_id) {

        $stmt = $conn->prepare(
            "SELECT student_id, session_date, start_time
             FROM sessions
             WHERE session_id = ? AND alumni_id = ? AND status = 'pending'
             FOR UPDATE"
        );
        $stmt->bind_param("ii", $session_id, $alumni_id);
        $stmt->execute();
        $session = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$session) {
            throw new ApiException("Session could not be declined", 404);
        }

        $stmt = $conn->prepare(
            "UPDATE sessions SET status = 'cancelled'
             WHERE session_id = ? AND alumni_id = ? AND status = 'pending'"
        );
        $stmt->bind_param("ii", $session_id, $alumni_id);
        $stmt->execute();
        $stmt->close();

        add_notification(
            $conn,
            "student",
            (int)$session["student_id"],
            "Session Request Declined",
            display_name($conn, "alumni", $alumni_id)
                . " declined your mentorship request for "
                . slot_text($session["session_date"], $session["start_time"]) . "."
        );
    });

    json_response(["success" => true, "message" => "Session request declined"]);
}


/* =========================================================
   CANCEL SESSION  (student cancels own / alumni cancels own)
   ========================================================= */
if ($action === "cancel") {

    $auth = require_auth();
    $role = $auth["role"];
    $user_id = $auth["id"];

    $session_id = post_int("session_id");
    $reason = post_string("reason", 500);

    if (!$session_id) {
        throw new ApiException("Invalid session.", 400);
    }

    // Column names come from this fixed whitelist, never from user input.
    $ownerColumn = $role === "student" ? "student_id" : "alumni_id";
    $otherRole = $role === "student" ? "alumni" : "student";
    $otherColumn = $role === "student" ? "alumni_id" : "student_id";

    with_transaction($conn, function () use ($conn, $role, $user_id, $session_id, $reason, $ownerColumn, $otherRole, $otherColumn) {

        $stmt = $conn->prepare(
            "SELECT $otherColumn AS other_id, availability_id, status, session_date, start_time
             FROM sessions
             WHERE session_id = ? AND $ownerColumn = ? AND status IN ('pending', 'confirmed')
             FOR UPDATE"
        );
        $stmt->bind_param("ii", $session_id, $user_id);
        $stmt->execute();
        $session = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$session) {
            throw new ApiException("Session could not be cancelled", 404);
        }

        $stmt = $conn->prepare(
            "UPDATE sessions SET status = 'cancelled'
             WHERE session_id = ? AND $ownerColumn = ? AND status IN ('pending', 'confirmed')"
        );
        $stmt->bind_param("ii", $session_id, $user_id);
        $stmt->execute();
        $stmt->close();

        // A confirmed session was holding the slot: make it bookable again.
        if ($session["status"] === "confirmed" && $session["availability_id"] !== null) {
            $availability_id = (int)$session["availability_id"];
            $stmt = $conn->prepare(
                "UPDATE availability SET status = 'available'
                 WHERE availability_id = ? AND status = 'booked'"
            );
            $stmt->bind_param("i", $availability_id);
            $stmt->execute();
            $stmt->close();
        }

        $who = display_name($conn, $role, $user_id);
        $text = "$who cancelled the mentorship session on "
            . slot_text($session["session_date"], $session["start_time"]) . ".";
        if ($reason !== "") {
            $text .= " Reason: $reason";
        }

        add_notification($conn, $otherRole, (int)$session["other_id"], "Session Cancelled", $text);
    });

    json_response(["success" => true, "message" => "Session cancelled successfully"]);
}

throw new ApiException("Invalid action.", 400);
