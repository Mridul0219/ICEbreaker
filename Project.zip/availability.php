<?php
/*
 * POST availability.php  action=add     date, start_time, duration
 * POST availability.php  action=delete  availability_id
 * Alumni only. The alumni is taken from the PHP session, so nobody can
 * add or remove another alumni's slots.
 */

require_once "helpers.php";

require_method("POST");
$auth = require_auth("alumni");
$alumni_id = $auth["id"];

$action = post_string("action", 20);

/* =========================
   ADD AVAILABILITY
   ========================= */
if ($action === "add") {

    $date = post_string("date", 10);
    $start_time = normalize_time(post_string("start_time", 8));
    $duration = post_int("duration");

    if (!valid_date($date) || !$start_time || !$duration) {
        throw new ApiException("Missing availability information", 400);
    }
    if ($duration < 15 || $duration > 480) {
        throw new ApiException("Duration must be between 15 and 480 minutes.", 400);
    }

    // end_time = start_time + duration (calculated on the server)
    [$h, $m] = array_map("intval", explode(":", $start_time));
    $endMinutes = $h * 60 + $m + $duration;

    if ($endMinutes >= 24 * 60) {
        throw new ApiException("A slot must end before midnight.", 400);
    }
    $end_time = sprintf("%02d:%02d:00", intdiv($endMinutes, 60), $endMinutes % 60);

    $stmt = $conn->prepare(
        "INSERT INTO availability (alumni_id, available_date, start_time, end_time, status)
         VALUES (?, ?, ?, ?, 'available')"
    );
    $stmt->bind_param("isss", $alumni_id, $date, $start_time, $end_time);
    $stmt->execute();
    $newId = $stmt->insert_id;
    $stmt->close();

    json_response([
        "success" => true,
        "message" => "Availability slot added successfully",
        "availability_id" => $newId
    ]);
}

/* =========================
   DELETE AVAILABILITY
   ========================= */
if ($action === "delete") {

    $availability_id = post_int("availability_id");
    if (!$availability_id) {
        throw new ApiException("Invalid availability slot.", 400);
    }

    with_transaction($conn, function () use ($conn, $availability_id, $alumni_id) {

        // Lock the slot; it must belong to THIS alumni.
        $stmt = $conn->prepare(
            "SELECT status FROM availability
             WHERE availability_id = ? AND alumni_id = ? FOR UPDATE"
        );
        $stmt->bind_param("ii", $availability_id, $alumni_id);
        $stmt->execute();
        $slot = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$slot) {
            throw new ApiException("Availability slot not found.", 404);
        }
        if ($slot["status"] !== "available") {
            throw new ApiException("Only available slots can be removed.", 409);
        }

        // A slot with a confirmed session must be cancelled through the session instead.
        $stmt = $conn->prepare(
            "SELECT 1 FROM sessions WHERE availability_id = ? AND status = 'confirmed' LIMIT 1"
        );
        $stmt->bind_param("i", $availability_id);
        $stmt->execute();
        $hasConfirmed = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($hasConfirmed) {
            throw new ApiException("This slot has a confirmed session. Cancel the session first.", 409);
        }

        // Pending requests for this slot can no longer be fulfilled: cancel them and tell the students.
        $stmt = $conn->prepare(
            "SELECT session_id, student_id, session_date, start_time
             FROM sessions
             WHERE availability_id = ? AND status = 'pending' FOR UPDATE"
        );
        $stmt->bind_param("i", $availability_id);
        $stmt->execute();
        $pending = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        if ($pending) {
            $alumniName = display_name($conn, "alumni", $alumni_id);

            $upd = $conn->prepare("UPDATE sessions SET status = 'cancelled' WHERE session_id = ?");
            foreach ($pending as $p) {
                $sid = (int)$p["session_id"];
                $upd->bind_param("i", $sid);
                $upd->execute();

                add_notification(
                    $conn,
                    "student",
                    (int)$p["student_id"],
                    "Session Request Cancelled",
                    "$alumniName removed the time slot on "
                        . slot_text($p["session_date"], $p["start_time"])
                        . ", so your session request was cancelled."
                );
            }
            $upd->close();
        }

        $stmt = $conn->prepare(
            "DELETE FROM availability WHERE availability_id = ? AND alumni_id = ?"
        );
        $stmt->bind_param("ii", $availability_id, $alumni_id);
        $stmt->execute();
        $stmt->close();
    });

    json_response(["success" => true, "message" => "Availability slot removed"]);
}

throw new ApiException("Invalid action.", 400);
