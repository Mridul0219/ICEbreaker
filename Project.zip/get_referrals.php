<?php
/*
 * GET get_referrals.php
 * Returns the referral requests of whoever is logged in
 * (student: their own requests, alumni: requests addressed to them).
 * role/user_id in the URL are ignored.
 */

require_once "helpers.php";

$auth = require_auth();

if ($auth["role"] === "student") {

    $stmt = $conn->prepare(
        "SELECT r.referral_id, r.alumni_id, r.company, r.position, r.cv_link,
                r.portfolio_link, r.message, r.status, r.proof_note, r.proof_link,
                r.created_at, r.updated_at,
                a.name AS alumni_name,
                a.company AS alumni_company,
                a.job_title AS alumni_job_title
         FROM referral_requests r
         INNER JOIN alumni a ON r.alumni_id = a.alumni_id
         WHERE r.student_id = ?
         ORDER BY r.created_at DESC, r.referral_id DESC"
    );

} else {

    $stmt = $conn->prepare(
        "SELECT r.referral_id, r.student_id, r.company, r.position, r.cv_link,
                r.portfolio_link, r.message, r.status, r.proof_note, r.proof_link,
                r.created_at, r.updated_at,
                s.name AS student_name,
                s.department AS student_department
         FROM referral_requests r
         INNER JOIN students s ON r.student_id = s.student_id
         WHERE r.alumni_id = ?
         ORDER BY r.created_at DESC, r.referral_id DESC"
    );
}

$stmt->bind_param("i", $auth["id"]);
$stmt->execute();
$referrals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

json_response(["success" => true, "referrals" => $referrals]);
