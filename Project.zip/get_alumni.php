<?php
/*
 * GET get_alumni.php            -> all alumni (for the logged-in student)
 * GET get_alumni.php?alumni_id= -> a single alumni
 * Password hashes are never selected.
 */

require_once "helpers.php";

require_auth("student");

$alumni_id = get_int("alumni_id");

$sql = "SELECT alumni_id, name, email, department, job_title, company,
               skills, bio, linkedin_link, portfolio_link
        FROM alumni";

if ($alumni_id) {
    $stmt = $conn->prepare($sql . " WHERE alumni_id = ?");
    $stmt->bind_param("i", $alumni_id);
} else {
    $stmt = $conn->prepare($sql . " ORDER BY name ASC");
}

$stmt->execute();
$alumni = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

json_response(["success" => true, "alumni" => $alumni]);
