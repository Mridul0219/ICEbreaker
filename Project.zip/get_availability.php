<?php
/*
 * GET get_availability.php?alumni_id=ID
 *   student -> the availability of the requested alumni
 *   alumni  -> ALWAYS their own availability (the id in the URL is ignored)
 */

require_once "helpers.php";

$auth = require_auth();

if ($auth["role"] === "alumni") {
    $alumni_id = $auth["id"];
} else {
    $alumni_id = filter_var($_GET["alumni_id"] ?? null, FILTER_VALIDATE_INT);
    if ($alumni_id === false || $alumni_id <= 0) {
        throw new ApiException("Invalid alumni ID", 400);
    }
}

$stmt = $conn->prepare(
    "SELECT availability_id, alumni_id, available_date, start_time, end_time, status
     FROM availability
     WHERE alumni_id = ?
     ORDER BY available_date ASC, start_time ASC"
);
$stmt->bind_param("i", $alumni_id);
$stmt->execute();
$availability = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

json_response(["success" => true, "availability" => $availability]);
